<template>
    <div id="app" class="app-main">
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                
            };
        },
        mounted () {

        },
        beforeDestroy () {

        },
        methods: {

        }
    };
</script>

<style>
html, body{
    height: 100%
}
.app-main{
    width: 100%;
    height: 100%;
}
</style>
